import React from 'react';
import './App.css';
import monday from 'monday-sdk-js';

class App extends React.Component {

  constructor(props) {
    super(props);
    // default state
    this.state = {
      settings: {},
      name: "",
    }
  }

  // initialize component with settings
  componentDidMount() {
    // Part 3: set up event listener
    // Part 4: make api call
  }

  render() {
    return (
      <div
        className="App" style={{background: (this.state.settings.background)}}
        >
        {// Part 2: add hello world}
      </div>
    );
  }
}

export default App;
