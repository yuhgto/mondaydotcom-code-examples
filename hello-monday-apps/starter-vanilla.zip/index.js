const monday = window.mondaySdk();

// add code below

// declare functions
function updateColor(settings) {

}
